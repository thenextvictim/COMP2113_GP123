#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "header.h"

using namespace std;


/*
struct role{
    string legend;
    string name;
    int damage;
    int health;
    int defense;
    int gold_coin;
    string weapon;
    string armor;
    bool holly_relic;
    string trash_talk[3];
};

role role1;

*/
role role1;

void gamesave(){
    ofstream fout;
    string savename;
    cout << "Please input your game name.";
    getline(cin,savename);
    fout.open(savename.c_str());

    if(fout.fail()){
        cout << "Error, game does not exist." << endl;
        fout.close();
    }
    else{
        // map.cpp
        //fout << "choose1" << " ";
        for (int i=0; i<5;i++){
            fout << choose1[i] << " ";
        }
        fout << endl;

        //fout << "choose2" << " ";
        for (int i=0; i<5;i++){
            fout << choose2[i] << " ";
        }
        fout << endl;

        //fout << "choice" << " ";
        for (int i=0; i<5;i++){
            fout << choice[i] << " ";
        }
        fout << endl;

        // role
        fout << status << endl;
        //fout << "role1" << " ";
        fout << role1.legend << " " ;
        fout << role1.name << " " ;
        fout << role1.damage << " " ;
        fout << role1.health << " " ;
        fout << role1.defense << " " ;
        fout << role1.gold_coin << " " ;
        fout << role1.weapon << " " ;
        fout << role1.armor << " " ;
        fout << role1.holly_relic << " " << endl;;
        for (int i=0; i<3; i++){
            fout << role1.trash_talk[i] << endl;
        }
        fout << endl;
        cout << "This game is saved." << endl;
        fout.close();
        fout.open("game_menu.txt");
        fout << savename << endl;
        fout.close();
    }
}

string choosegame(){
    ifstream fin;
    fin.open("game_menu.txt");
    vector<string> savenames;
    vector<string>::iterator itr;
    string savename;
    bool check = false;
    cout << "Existing games are as follows: " << endl;
    while(fin >> savename){
        cout << savename << endl;
        savenames.push_back(savename);
    }
    while(check == false){
        cout << "Please choose a game." << endl;
        cin >> savename;
        check = false;
        for (itr = savenames.begin(); itr != savenames.end(); itr++){
            if (savename == *itr){
                check = true;
            }
        }
        if (check == false){
            cout << "Game does not exist, please try again." << endl;
        }
        else {
            cout << "Load successfully.";
        }
    }
    return savename;
}

void loadgame(string savename){
    ifstream fin;
    int data;
    string data_str;
    fin.open(savename.c_str());
    for (int i=0; i<5; i++){
        fin >> data;
        choose1[i] = data;
    }
    for (int i=0; i<5; i++){
        fin >> data;
        choose2[i] = data;
    }
    for (int i=0; i<5; i++){
        fin >> data;
        choice[i] = data;
    }
    fin >> data;
    status = data;
    fin >> data_str;
    role1.legend = data_str;
    fin >> data_str;
    role1.name = data_str;
    fin >> data;
    role1.damage = data;
    fin >> data;
    role1.health = data;
    fin >> data;
    role1.defense = data;
    fin >> data;
    role1.gold_coin = data;
    fin >> data_str;
    role1.weapon = data_str;
    fin >> data_str;
    role1.armor = data_str;
    fin >> data;
    role1.holly_relic = data;
    getline(fin,data_str);
    for (int i=0; i<3; i++){
        getline(fin,data_str);
        role1.trash_talk[i] = data_str;
    }
    fin.close();
}


/*
int main(){
        role1.legend = "Human warrior";
        role1.damage = 20;
        role1.health = 100;
        role1.defense = 10;
        role1.gold_coin = 10;
        role1.weapon = "Nothing";
        role1.armor = "Nothing";
        role1.holly_relic = false;
        role1.trash_talk[0] = "In the name of justice, your guilty will be judged!";
        //“星星之火，可以燎原。”
        role1.trash_talk[1] = "A single spark can start a prairie fire";
        //"失去人性，失去很多。失去兽性，失去一切。"
        role1.trash_talk[2] = "Lose humanity, lose much. Lose animalistic nature, lose all.";
    string savename;   
    gamesave();
    savename = choosegame();
    loadgame(savename);
    cout << "choose1:" << endl;
    for (int i=0; i<5;i++){
            cout << choose1[i] << " ";
        }
        cout << endl;

        cout << "choose2:" << " ";
        for (int i=0; i<5;i++){
            cout << choose2[i] << " ";
        }
        cout << endl;

        cout << "choice" << " ";
        for (int i=0; i<5;i++){
            cout << choice[i] << " ";
        }
        cout << endl;

        // role
        cout << "status:" << " ";
        cout << status << endl;
        cout << "role1" << " ";
        cout << role1.legend << " " ;
        cout << role1.name << " " ;
        cout << role1.damage << " " ;
        cout << role1.health << " " ;
        cout << role1.defense << " " ;
        cout << role1.gold_coin << " " ;
        cout << role1.weapon << " " ;
        cout << role1.armor << " " ;
        cout << role1.holly_relic << " " << endl;
        for (int i=0; i<3; i++){
            cout << role1.trash_talk[i] << " " << endl;
        }

    return 0;
}
*/