//Portal.cpp
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "header.h"

using namespace std;



struct role{
    std::string legend;
    std::string name;
    int damage;
    int health;
    int defense;
    int gold_coin;
    std::string weapon;
    std::string armor;
    bool holly_relic;
    std::string trash_talk[3];
    role(std::string n, int HP, int attack, int def, int gold){
        name = n;
        health = HP;
        damage = attack;
        defense = def;
        gold_coin = gold;
    }
};



enum EffectType {
    MaxHP,
    ATTACK,
    DEFENSE,
    BLOCKS
};

struct shop_item {
    string name;
    string description;
    int price;
    EffectType effect_type;
    int effect_amount;
};

shop_item blood_potion = { "Blood potion","Raise your max HP by 20", 40, MaxHP, 20};
shop_item attack_potion = { "Attack potion","Raise your strength by 5", 30, ATTACK, 5};
shop_item earth_potion = { "Earth potion","Raise your defense value by 5", 40, DEFENSE, 5};
shop_item thorn_potion = { "Thorn potion","Obtain 10 blocks in your next battle", 40, BLOCKS, 10};
shop_item shop_item_potion_arr[4] = { blood_potion ,attack_potion ,earth_potion ,thorn_potion };


string invalid_input_1[8]= {
    "You try to do that, but it seems impossible. Perhaps there's another way?",
    "Your words fall on deaf ears. Perhaps there is another way?",
    "You cannot do that here, adventurer. Try again.",
    "The forces of magic ignore your command. What else would you like to try?",
    "The spirits of the forest seem to be watching you. Better not anger them with an invalid command.",
    "Your attempt to interact with the environment was fruitless. Maybe there's another way?",
    "Your attempt to manipulate the world around you has failed. Think carefully about what you want to do next.",
    "The world around you remains still and silent, indifferent to your actions. Please try again with a different approach."
};
string invalid_input_2[8]= {
    "The hero within you yearns to succeed, but that's not going to work.",
    "The enemy seems to be waiting for you to make a move. Choose more carefully.",
    "Your instincts tell you that won't end well. Better come up with a new strategy.",
    "The shadows whisper with malevolence. You quickly rethink your approach.",
    "The darkness seems to be closing in around you. Better try a different command.",
    "The darkness around you seems to grow deeper as if it's closing in. Try something else before it's too late.",
    "The air grows thick with tension as if something is about to happen. But not with that command.",
    "You feel a sense of foreboding as you realize that won't work. There must be another way forward.",
};

string continue_input_1[6]= {
    "The path ahead is filled with danger and uncertainty. But you're ready for whatever comes next. \nPress \033[1;34m[Enter]\033[0m when you're prepared to move forward.",
    "You feel a sense of satisfaction as you complete the task at hand. But there's still much to be done. \nHit \033[1;34m[Enter]\033[0m to continue your journey.",
    "As you gaze out over the horizon, you realize just how far you've come. But there's still a long road ahead. \nPress \033[1;34m[Enter]\033[0m to keep moving forward.",
    "The mysteries of this world never cease to amaze you. \nPress \033[1;34m[Enter]\033[0m when you're ready to uncover the next one.",
    "The path ahead is shrouded in mist, but your determination is clear as day. \nPress \033[1;34m[Enter]\033[0m when you're ready to take the next step.",
    "The path ahead may be shrouded in darkness, but you have the light of courage to guide you. \nPress \033[1;34m[Enter]\033[0m to keep moving forward."
};
string continue_input_2[6]= {
    "Your journey through this dark and foreboding world has only just begun. \nPress \033[1;34m[Enter]\033[0m to step boldly into the unknown.",
    "With the creature vanquished, you take a moment to catch your breath and prepare for what lies ahead. \nPress \033[1;34m[Enter]\033[0m to continue your journey.",
    "With the enemy vanquished, you pause to catch your breath and survey your surroundings. But time is running short. \nHit \033[1;34m[Enter]\033[0m to continue your quest.",
    "The darkness around you seems to thicken, as if something is waiting just beyond the shadows. But you're not afraid. \nPress \033[1;34m[Enter]\033[0m to step boldly into the unknown.",
    "The world trembles beneath your feet as you complete your task. But there's no time to celebrate. \nHit \033[1;34m[Enter]\033[0m to continue your fight against the encroaching darkness.",
    "Every challenge you overcome makes you stronger. Eeady yourself for what lies ahead. \nHit \033[1;34m[Enter]\033[0m to move forward."
};

string invalid_input_shop[] = {
    "The shopkeeper raises an eyebrow at you. \"Sorry, we don't have that item in stock. Can I help you find something else?\"",
    "The shopkeeper glances at the empty space on the shelf where that item used to be. \"Sorry, we're sold out right now. Can i interest you in something else?\""
};



const string Dividing_line = "-------------------------------------------------------------------\n";

void Portal(int& num){
    string command;
    cout << Dividing_line
         << "Before you is a sight that seems out of place in the landscape around you. Strangely placed into one of the wall is an enclosed stone entrance filled with a " << "\033[35mswirling magical portal\033[0m" << ".\n" 
         << "You aren't sure where it leads, but maybe it could speed your journey through the Forest.\n";
    cout << Dividing_line
         << "1. " << "\033[1;34m[Enter the Portal]\033[0m Travel to an unknown place.\n" 
         << "2. " << "\033[1;34m[Leave]\033[0m Nothing happens.\n\n";

    getline(cin,command);
    while(command != "1" && command != "2"){
            cout << invalid_input_1[rand()%(sizeof(invalid_input_1)/sizeof(invalid_input_1[0]))] << endl;
            getline(cin,command);
        }
    // Handle command.
    cout << Dividing_line;
    if (command == "1"){
        num += 1;
        // change position of player1

        cout << "Jumping through the portal, your sense of time and space is completely torn apart.\n"
             << "As you reorient yourself to the new surroundings, you realize that you have come to a strange place.\n";
    }
    else {
        cout << "Careful and cautious seems the better approach for reaching the top of the Spire. Ignoring the portal you continue on.\n";
    }
    //cout << Dividing_line << "1. \033[1;34m[Continue]\033[0m\n\n";
    cout << Dividing_line << continue_input_1[rand()%(sizeof(continue_input_1)/sizeof(continue_input_1[0]))] << endl;
    // getline(cin,command);
}

void Golden_Shrine(role& player){
    string command;
    cout << Dividing_line << "Before you lies an elaborate shrine to an ancient spirit.\n";
    cout << Dividing_line
        << "1. " << "\033[1;34m[Pray]\033[0m Gain 100 \033[1;33mGold\033[0m.\n"
        << "2. " << "\033[1;34m[Desecrate]\033[0m Gain 275 \033[1;33mGold\033[0m. Become Cursed.\n"
        << "3. " << "\033[1;34m[Leave]\033[0m Nothing happens.\n\n";
    getline(cin,command);
    while(command != "1" && command != "2" && command != "3"){
        cout << invalid_input_1[rand()%(sizeof(invalid_input_1)/sizeof(invalid_input_1[0]))] << endl;
        getline(cin,command);
    }
    cout << Dividing_line;
    if (command == "1"){
        player.gold_coin += 100;
        cout << "As your hand touches the shrine, gold rains from the ceiling showering you in riches.\n";
    }
    else if (command == "2"){
        player.gold_coin += 275;
        player.damage -= 3;
        cout << "Each time you strike the shrine, gold pours forth again and again!\n"
             << "As you pocket the riches, something " << "\033[1;31mweighs heavily on you.\033[0m\n";
    }
    else if (command == "3"){
        cout << "You ignore the shrine.\n";
    }
    //cout << Dividing_line << "1. \033[1;34m[Continue]\033[0m\n\n";
    cout << Dividing_line << continue_input_1[rand()%(sizeof(continue_input_1)/sizeof(continue_input_1[0]))] << endl;
    // getline(cin,command);
}

void Treasure_chest(role& player){
    string command;
    bool mimic = (rand() % 2 == 1);
    if (mimic){
        // Mimic
        cout << Dividing_line << "You stumble upon a wooden box. It seems to be a little broken, the lock on it has rusted and damaged. Along with your approach, it emits a slight shaking.\n";
        cout << Dividing_line
            << "1. " << "\033[1;34m[\"Open\"]\033[0m Try to get the treasure within\n"
            << "2. " << "\033[1;34m[Leave]\033[0m Back away slowly\n\n";
        getline(cin,command);
        while(command != "1" && command != "2"){
            cout << invalid_input_1[rand()%(sizeof(continue_input_1)/sizeof(continue_input_1[0]))] << endl;
            getline(cin,command);
        }
        cout << Dividing_line;
        if (command == "1"){
            cout << "As you reach for the lock, the chest suddenly springs open revealing its true form: a grotesque monster with jagged teeth and a slimy maw!\n";
            cout << Dividing_line
            << "1. " << "\033[1;34m[Fight]\033[0m Prepare for a fierce battle\n"
            << "2. " << "\033[1;34m[Escape]\033[0m Flee from the abomination\n\n";
            getline(cin,command);
            while(command != "1" && command != "2"){
                cout << invalid_input_2[rand()%(sizeof(continue_input_2)/sizeof(continue_input_2[0]))] << endl;
                getline(cin,command);
            }
            cout << Dividing_line;
            if (command == "1"){
                cout << "Steel yourself for the coming fight!\n";
                // Fight
                // if Win:
                    cout << "With a final blow, you vanquish the gruesome mimic.\n"
                        << "You discover a hoard of treasure within the remains, including a rare piece of equipment.\n";
                    player.gold_coin += 200 + rand()%50;
                    // Get Equitment
                // if Lose
                    // endGame();

            }
            else if (command == "2"){
                cout << "You turn tail and run as fast as you can, barely escaping the clutches of the mimic.\n";
            }
        }
        else if (command == "2"){
            cout << "You wisely choose to back away from the dangerous-looking chest.\n";
        }
        //cout << Dividing_line << "1. \033[1;34m[Continue]\033[0m\n\n";
        cout << Dividing_line << continue_input_2[rand()%(sizeof(continue_input_2)/sizeof(continue_input_2[0]))] << endl;
        // getline(cin,command);
    }
    else {
        // Treasure Chest
        cout << Dividing_line << "You find a sturdy wooden chest, its lock undamaged and gleaming in the light. It appears to be filled with riches.\n";
        cout << Dividing_line
            << "1. " << "\033[1;34m[Open]\033[0m See what's inside\n"
            << "2. " << "\033[1;34m[Leave]\033[0m Leave it be\n\n";
        getline(cin,command);
        while(command != "1" && command != "2"){
            cout << invalid_input_1[rand()%(sizeof(invalid_input_1)/sizeof(invalid_input_1[0]))] << endl;
            getline(cin,command);
        }
        cout << Dividing_line;
        if (command == "1"){
            cout << "You successfully pry open the chest, revealing a trove of treasure within: gold coins, gems, and a valuable piece of equipment.\n";
            player.gold_coin += 90 + rand()%20;
            // Get an equipment;
        }
        else if (command == "2"){
            cout << "You decide to leave the chest alone and continue on your way.\n";
        }
        //cout << Dividing_line << "1. \033[1;34m[Continue]\033[0m\n\n";
        cout << Dividing_line << continue_input_1[rand()%(sizeof(continue_input_1)/sizeof(continue_input_1[0]))] << endl;
        // getline(cin,command);
    }
}

void Lab(role& player){
    string command;
    int index[3]={0,0,0};
    index[0] = rand()%3;
    while(index[0] == index[1]){
        index[1] = rand()%3;
    }
    while(index[0] == index[2] || index[1] == index[2]){
        index[2] = rand()%3;
    }
    cout << Dividing_line << "You find yourself in a room filled with racks of test tubes, beakers, flasks, forceps, pinch clamps, stirring rods, tongs, goggles, funnels, pipets, cylinders, condensers, and even a rare spiral tube of glass.\nWhy do you know the name of all these tools? It doesn't matter, you take a look around.\n";
    for (int i=0; i<3; i++){
    cout << Dividing_line
        << "1. " << "\033[1;34m[Search]\033[0m Obtain a random Potions\n\n";
    getline(cin,command);
    while(command != "1"){
        cout << invalid_input_1[rand()%(sizeof(invalid_input_1)/sizeof(invalid_input_1[0]))] << endl;
        getline(cin,command);
    }
    cout << Dividing_line;
    if (command == "1"){
        cout << "You find a " << shop_item_potion_arr[index[i]].name << endl;
                switch (shop_item_potion_arr[index[i]].effect_type) {
                case MaxHP:
                    player.health += shop_item_potion_arr[index[i]].effect_amount;
                    cout << "As you drink the potion, your wounds heal and your body becomes more resilient. You feel your maximum health increase." << endl;
                    break;
                case ATTACK:
                    player.damage += shop_item_potion_arr[index[i]].effect_amount;
                    cout << "The elixir surges through your veins, sharpening your senses and increasing your attack power!" << endl;
                    break;
                case DEFENSE:
                    player.defense += shop_item_potion_arr[index[i]].effect_amount;
                    cout << "You feel the potion's power moving through you, as if it were part of your very being. your defense is now even stronger than before." << endl;
                    break;
                case BLOCKS:
                    // Add code to apply block effect
                    cout << "The potion fortifies your shield arm, allowing you to block and deflect attacks with greater ease and effectiveness." << endl;
                    break;
                }
        }
    }
    cout << Dividing_line
        << "1. " << "\033[1;34m[Leave]\033[0m Nothing happens.\n\n";
    getline(cin,command);
    while(command != "1"){
        cout << invalid_input_1[rand()%(sizeof(invalid_input_1)/sizeof(invalid_input_1[0]))] << endl;
        getline(cin,command);
    }
    cout << Dividing_line << continue_input_1[rand()%sizeof(continue_input_1)/sizeof(continue_input_1[0])] << endl;
}

void randomEvent(role& player){
    switch (rand()%3)
    {
    case 0:
        Golden_Shrine(player);
        break;
    case 1:
        Treasure_chest(player);
        break;
    case 2:
        Lab(player);
        break;
    }
}

int main(){
    string command;
    srand((int)time(0));
    int choose[5][2], position[2]={3,1};
    role Player = { "Player",50,25,5,10 };
    while (true){
        randomEvent(Player);
        getline(cin, command);
    }
    return 0;
}

